﻿using Newtonsoft.Json.Linq;
using PaPetrolimex.Commons;
using PaPetrolimex.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml;

namespace PaPetrolimex.Helpers
{
    public class ApiHelper
    {
        private static ApiHelper _INSTANCE;
        public static ApiHelper INSTANCE => _INSTANCE ?? (_INSTANCE = new ApiHelper());
        //private CookieCollection Cookies { get; set; }
        private HttpClient Client { get; set; }
        public ApiHelper() { }

        public async Task CreateInstanceHttpClient()
        {
            if (Client == null)
            {
                Client = new HttpClient();
                await Client.GetAsync(CmmVariable.DOMAIN);
            }
        }

        public async Task<Stream> DownloadFile(string url, CancellationToken cancellationToken = new CancellationToken())
        {
            url = CmmVariable.DOMAIN + (string.IsNullOrEmpty(CmmVariable.SUBSITE) ? "" : $"/{CmmVariable.SUBSITE}/") + url.TrimStart('/');
            try
            {
                return await Client.GetStreamAsync(url, cancellationToken);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"DownloadFile error: {ex.ToString()}");
            }

            return null;
        }
        public async Task<JObject> GetJObjectAsync(string url, CancellationToken cancellationToken = default)
        {
            url = CmmVariable.DOMAIN + (string.IsNullOrEmpty(CmmVariable.SUBSITE) ? "" :$"/{CmmVariable.SUBSITE}/") + url.TrimStart('/');

            var resString = await Client.GetStringAsync(url, cancellationToken);
            try
            {
                return JObject.Parse(resString);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GetJObjectAsync error: {ex.ToString()}");
            }

            return null;
        }
        public async Task<ApiResponse<T>> GetAsync<T>(string url, CancellationToken cancellationToken = default)
        {
            url = CmmVariable.DOMAIN + (string.IsNullOrEmpty(CmmVariable.SUBSITE) ? "" : $"/{CmmVariable.SUBSITE}/") + url.TrimStart('/');

            try
            {
                using (Stream stream = await Client.GetStreamAsync(url, cancellationToken: cancellationToken))
                {
                    ApiResponse<T> ret = await JsonSerializer.DeserializeAsync<ApiResponse<T>>(stream, cancellationToken: cancellationToken);
                    return ret;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"GetUrlAsync error: {url} - {ex.ToString()}");
            }

            return null;
        }

        public async Task<T> PostAsync<T>(string url, CancellationToken cancellationToken = default)
        {


            return default(T);
        }

        public async Task<bool> Auth(string uname, string pswd, CancellationToken cancellationToken = new CancellationToken())
        {
            string xmlSOAP = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body>"
                + "<Login xmlns=\"http://schemas.microsoft.com/sharepoint/soap/\">"
            + $"<username>{uname}</username><password>{pswd}</password></Login></soap:Body></soap:Envelope>";

            //Client = new HttpClient(new HttpClientHandler { UseProxy = false, ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => true });
            HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, CmmVariable.DOMAIN + "/_vti_bin/authentication.asmx");
            req.Content = new StringContent(xmlSOAP);
            req.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("text/xml; charset=utf-8");
            HttpResponseMessage response = await Client.SendAsync(req, cancellationToken);

            if (response.IsSuccessStatusCode)
                return true;

            return false;
        }
    }
}
