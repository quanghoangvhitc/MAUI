﻿using PaPetrolimex.Commons;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex
{
    public static class StringExts
    {
        public static string UrlWithDomain(this string url)
        {
            url = CmmVariable.DOMAIN + (string.IsNullOrEmpty(CmmVariable.SUBSITE) ? "" : $"/{CmmVariable.SUBSITE}/") + url.TrimStart('/');

            return url;
        }
    }
}
