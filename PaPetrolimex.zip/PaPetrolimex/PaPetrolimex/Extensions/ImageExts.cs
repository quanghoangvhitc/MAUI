﻿using Microsoft.Maui.Controls.Internals;
using PaPetrolimex.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex.Extensions
{
    public static class ImageExts
    {
        public static async Task<Stream> GetStreamAsync(this Image image, string url, CancellationToken cancellationToken = new CancellationToken())
        {
            try
            {
                if (!string.IsNullOrEmpty(url))
                {
                    Stream imgStream = await ApiHelper.INSTANCE.DownloadFile(url, cancellationToken);
                    return imgStream;
                }
            }
            catch (Exception ex)
            { }
            return null;
        }

        public static async Task<Stream> GetCompressImageStream(this Image image, string url, CancellationToken cancellationToken = new CancellationToken())
        {
            try
            {
                if (string.IsNullOrEmpty(url))
                    return null;

                Stream stream = await ApiHelper.INSTANCE.DownloadFile(url, cancellationToken);

                Microsoft.Maui.Graphics.IImage iimg = null;
                Microsoft.Maui.Graphics.IImage iimgTmp = null;
                await App.Current.Dispatcher.DispatchAsync(() =>
                {
#if ANDROID || IOS || MACCATALYST
                iimg  = Microsoft.Maui.Graphics.Platform.PlatformImage.FromStream(stream);
#endif
                    //ImageSource imageSource = ImageSource.FromStream(() => stream);
                    //Image image = new Image();
                    //image.Source = imageSource;

                    //Microsoft.Maui.Graphics.IImage iimg = image as Microsoft.Maui.Graphics.IImage;
                    if (iimg != null)
                    {
                        iimgTmp = iimg.Downsize(50);
                        iimg.Dispose();
                    }
                });

                if (iimgTmp != null)
                    return iimgTmp.AsStream(ImageFormat.Png);
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        public static async Task ImageLazyLoadUrl(this Image image, string url, CancellationToken cancellationToken = new CancellationToken())
        {
            if (!string.IsNullOrEmpty(url))
            {
                Stream imgStream = await ApiHelper.INSTANCE.DownloadFile(url, cancellationToken);

                if (imgStream != null)
                {
                    var imgSource = ImageSource.FromStream(() => imgStream);
                    if (imgSource != null)
                    {
                        image.Dispatcher.Dispatch(() =>
                        {
                            if (cancellationToken.IsCancellationRequested)
                                return;
                            image.Source = imgSource;
                        });
                    }
                }
            }
            //await App.Current.Dispatcher.DispatchAsync(new Action(() =>
            //{
            //    if (imgStream != null)
            //    {
            //        var imgSource = ImageSource.FromStream(() => imgStream);
            //        if (imgSource != null)
            //            image.Source = imgSource;
            //    }
            //}));
        }
    }
}
