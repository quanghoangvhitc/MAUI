using Microsoft.Maui.Controls;
using Newtonsoft.Json.Linq;
using PaPetrolimex.Extensions;
using PaPetrolimex.Models;

namespace PaPetrolimex.CollectionItems;

public partial class ViecCanXuLyItem : ViewCell
{
    CancellationTokenSource tokenSource = null;
    public ViecCanXuLyItem()
    {
        InitializeComponent();
        this.BindingContextChanged += ViecCanXuLyItem_BindingContextChanged;
    }

    private async void ViecCanXuLyItem_BindingContextChanged(object sender, EventArgs e)
    {
        if (tokenSource != null)
            tokenSource.Cancel();

        tokenSource = new CancellationTokenSource();

        Notify item = this.BindingContext as Notify;

        //JToken item = this.BindingContext as JToken;

        lblSendUnit.Text = item.SendUnit;
        lblCategory.Text = item.Category;
        lblTitle.Text = item.Title;
        lblAction.Text = item.Action;

        imgAvatar.GetStreamAsync(item.ImagePath, tokenSource.Token).ContinueWith(task =>
        {
            //App.Current.Dispatcher.Dispatch(() =>
            //{
                Stream stream = task.Result;
                if (stream != null)
                {
                    var imgSource = ImageSource.FromStream(() => task.Result);
                    if (imgSource != null && !task.IsCanceled)
                        imgAvatar.Source = imgSource;
                }
            //});
        });
    }
}