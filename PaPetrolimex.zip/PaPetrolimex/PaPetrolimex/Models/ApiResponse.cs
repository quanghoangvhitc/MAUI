﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex.Models
{
    public class ApiResponse<T>
    {
        public string status { get; set; }
        public KeyValuePair<string, string> mess { get; set; }
        public T data { get; set; }
        public ExpandoObject moreData { get; set; }
        public string dateNow { get; set; }
    }
}
