﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex.Models
{
    public class ApiData<T>
    {
        public T Data { get; set; }
        public List<MoreData> MoreInfo { get; set; }
        public int TotalRecord
        {
            get
            {
                if(MoreInfo.Count > 0)
                    return MoreInfo[0].totalRecord;
                return -1;
            }
        }
    }

    public class MoreData
    {
        public int totalRecord { get; set; }
    }
}
