﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex.Models
{
    public class Notify
    {
        private static readonly string UrlViecCanXuLy = "/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=HomeNotify";
        public static string GetUrlViecCanXuLy(params string[] pars)
        {
            string url = UrlViecCanXuLy;

            foreach (string p in pars)
                url += $"&{p}";

            return url;
        }

        public string ID { get; set; }
        public string Title { get; set; }
        public string URL { get; set; }
        public Decimal? DocumentID { get; set; }
        public string Category { get; set; }
        public bool? Type { get; set; }
        public DateTime? Created { get; set; }
        public DateTime? Modified { get; set; }
        public string SendUnit { get; set; }
        public int? Priority { get; set; }
        public int? Status { get; set; }
        public DateTime? DueDate { get; set; }
        public bool? Read { get; set; }
        public string ListName { get; set; }
        public Decimal? TaskID { get; set; }
        public string ImagePath { get; set; }
        public string Position { get; set; }
        public string SiteName { get; set; }
        public string Action { get; set; }
    }
}
