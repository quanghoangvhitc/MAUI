﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex.Models
{
    public class User
    {
        public string ID { get; set; }
        public int AccountID { get; set; }
        public string AccountName { get; set; }
        public string FullName { get; set; }
        public Decimal DepartmentID { get; set; }
        public string Email { get; set; }
        public string Position { get; set; }
        public string ImagePath { get; set; }
        public string SiteName { get; set; }
        public int UserStatus { get; set; }
        public DateTime? Modified { get; set; }
        public static string ApiCurrentUser => "/vanban/_layouts/15/VuThao.PA.API/ApiMobile.ashx?func=Get&function=CurrentUser";

    }
}
