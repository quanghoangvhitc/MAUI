﻿using Newtonsoft.Json.Linq;
using PaPetrolimex.ContentPages;
using PaPetrolimex.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaPetrolimex.Commons
{
    public class CmmVariable
    {
        public static readonly string DOMAIN = "https://petrolimex.vuthao.com";
        public static readonly string SUBSITE = "";

        public static User CurrentUser = null;
    }
}
