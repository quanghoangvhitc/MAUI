﻿using Microsoft.Maui.Platform;
using Newtonsoft.Json.Linq;
using PaPetrolimex.Commons;
using PaPetrolimex.ContentPages;
using PaPetrolimex.Helpers;
using PaPetrolimex.Models;
using System.Diagnostics;

namespace PaPetrolimex;

public partial class MainPage : ContentPage
{
	int count = 0;
    List<Notify> notifys = null;

    public MainPage()
	{
		InitializeComponent();
        entryUsername.Completed += EntryUsername_Completed;
        entryPassword.Completed += EntryPassword_Completed;
    }

    private void EntryPassword_Completed(object sender, EventArgs e)
    {
#if ANDROID
        if (Platform.CurrentActivity.CurrentFocus != null)
        {
            Platform.CurrentActivity.HideKeyboard(Platform.CurrentActivity.CurrentFocus);
        }
#endif
    }

    private void EntryUsername_Completed(object sender, EventArgs e)
    {
#if ANDROID
        if(Platform.CurrentActivity.CurrentFocus != null)
        {
            Platform.CurrentActivity.HideKeyboard(Platform.CurrentActivity.CurrentFocus);
        }
#endif
    }

    private async void btnLogin_Clicked(object sender, EventArgs e)
    {
        lblLoginStatus.Text = $"Please wait...";
        SemanticScreenReader.Announce(lblLoginStatus.Text);
        Stopwatch stopwatch = Stopwatch.StartNew();
        var IsLogin = await ApiHelper.INSTANCE.Auth(entryUsername.Text, entryPassword.Text);
        Console.WriteLine($"Login completed: {stopwatch.ElapsedMilliseconds} - Status: {IsLogin}");
        stopwatch.Stop();

        if (IsLogin)
        {
            //Dashboard dashboard = new Dashboard(notifys);
            //await Navigation.PushAsync(dashboard).ContinueWith(task =>
            //{
            //    GetCurrentUser();
            //});
            GetNotify();

            Dashboard dashboard = new Dashboard();

            await Navigation.PushAsync(dashboard).ContinueWith(task =>
            {
                GetCurrentUser();

                while (notifys != null)
                {
                    dashboard.Notifys = notifys;
                }
            });
        }
        else
        {
            await DisplayAlert("PA PETRO", "Đăng nhập thất bại", "OK");
            lblLoginStatus.Text = $"";
        }
    }

    private async Task GetCurrentUser()
    {
        ApiResponse<List<User>> ret = await ApiHelper.INSTANCE.GetAsync<List<User>>(User.ApiCurrentUser);
        if (ret == null)
            return;

        if (ret.status == "SUCCESS")
        {
            if (ret.data != null)
                CmmVariable.CurrentUser = ret.data[0];
        }

        return;
    }

    private async Task GetNotify()
    {
        string urlNotify = Notify.GetUrlViecCanXuLy(new[]
            {
                "Status=0",
                "Offset=0",
                "Limit=50",
                "IsCount=0",
                "params=Limit,Offset,IsCount,Status"
            });

        ApiResponse<ApiData<List<Notify>>> ret = await ApiHelper.INSTANCE.GetAsync<ApiData<List<Notify>>>(urlNotify);

        if (ret == null)
            return;

        if (ret.status == "SUCCESS")
            notifys = ret.data.Data;

        return;
    }
}

