using Newtonsoft.Json.Linq;
using PaPetrolimex.Commons;
using PaPetrolimex.Helpers;
using PaPetrolimex.Models;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace PaPetrolimex.ContentPages;

public partial class Dashboard : ContentPage, INotifyPropertyChanged
{
    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public event PropertyChangedEventHandler PropertyChanged;

    private List<Notify> _Notifys;
    public List<Notify> Notifys
    {
        get => _Notifys;
        set
        {
            _Notifys = value;
            OnPropertyChanged();
        }
    }

    public Dashboard()
    {
        InitializeComponent();
    }

    protected override bool OnBackButtonPressed()
    {

        //return base.OnBackButtonPressed();
        return true;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
    }

    private async Task GetCurrentUser()
    {
        ApiResponse<List<User>> ret = await ApiHelper.INSTANCE.GetAsync<List<User>>(User.ApiCurrentUser);
        if (ret == null)
            return;

        if (ret.status == "SUCCESS")
        {
            if (ret.data != null)
                CmmVariable.CurrentUser = ret.data[0];
        }

        return;
    }

    private async Task GetNotify()
    {
        string urlNotify = Notify.GetUrlViecCanXuLy(new[]
            {
                "Status=0",
                "Offset=0",
                "Limit=10",
                "IsCount=0",
                "params=Limit,Offset,IsCount,Status"
            });

        ApiResponse<ApiData<List<Notify>>> ret = await ApiHelper.INSTANCE.GetAsync<ApiData<List<Notify>>>(urlNotify);

        if (ret == null)
            return;

        if (ret.status == "SUCCESS")
            Notifys = ret.data.Data;

        return;
    }
}