﻿using PaPetrolimex.Helpers;

namespace PaPetrolimex;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		ApiHelper.INSTANCE.CreateInstanceHttpClient();

		MainPage = new AppShell();
	}
}
