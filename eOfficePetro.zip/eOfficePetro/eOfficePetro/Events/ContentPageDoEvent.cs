﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eOfficePetro.Events
{
    public class ContentPageDoEvent : EventArgs
    {
        public string ClassName { get; set; }
        public string Name { get; set; }
        public EventArgs e { get; set; }
        public ContentPageDoEvent(string ClassName, string Name, EventArgs e) 
        {
            this.ClassName = ClassName;
            this.Name = Name;
            this.e = e;
        }
    }
}
