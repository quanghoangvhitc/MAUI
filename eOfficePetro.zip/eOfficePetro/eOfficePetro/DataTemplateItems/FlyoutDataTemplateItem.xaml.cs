using eOfficePetro.FlyoutPages;

namespace eOfficePetro.DataTemplateItems;

public partial class FlyoutDataTemplateItem : ContentView
{
    //CancellationTokenSource tokenSource = null;
    public FlyoutDataTemplateItem()
	{
		InitializeComponent();
        this.BindingContextChanged += FlyoutDataTemplateItem_BindingContextChanged;
	}

    private void FlyoutDataTemplateItem_BindingContextChanged(object sender, EventArgs e)
    {
        //if (tokenSource != null)
        //    tokenSource.Cancel();

        //tokenSource = new CancellationTokenSource();

        FlyoutPageItem item = this.BindingContext as FlyoutPageItem;
        if(item != null)
        {
            if(item.MenuItemType == FlyoutMenuItemType.Title)
            {
                this.BackgroundColor = Colors.White;
                grdMenu.IsVisible = false;

                lblTitle.Text = item.Title;
                grdTitle.IsVisible = true;
            }    
            else
            {
                lblMenu.Text = item.Title;
            }    
        }
    }
}