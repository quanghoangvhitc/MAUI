using eOfficePetro.Events;
using eOfficePetro.Pages;
using static Android.Content.ClipData;

namespace eOfficePetro.FlyoutPages;

public partial class AppFlyout : FlyoutPage
{
	public AppFlyout()
	{
		InitializeComponent();
        IsGestureEnabled = false;
        flyoutPage.collectionView.SelectionChanged += OnSelectionChanged;
        
        HomePage.DoEvent += HomePage_DoEvent;
        LoginPage.DoEvent += HomePage_DoEvent;
    }

    private void HomePage_DoEvent(object sender, ContentPageDoEvent e)
    {
        switch (e.ClassName)
        {
            case nameof(HomePage):
                {
                    switch (e.Name)
                    {
                        case "imgAvatar":
                            {
                                IsPresented = true;
                            }
                            break;
                    }
                }
                break;
            case nameof(LoginPage):
                {
                    switch (e.Name)
                    {
                        case "btnLogin":
                            {
                                IsGestureEnabled = true;
                                HomePage page = new HomePage();
                                Detail = new NavigationPage(page);
                            }
                            break;
                    }
                }
                break;
        }
    }

    private bool IsFlyoutPrevious = false;
    void OnSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (IsFlyoutPrevious)
        {
            IsFlyoutPrevious = false;
            return;
        }

        FlyoutPageItem item = e.CurrentSelection.FirstOrDefault() as FlyoutPageItem;
        if (item != null && item.MenuItemType == FlyoutMenuItemType.Menu)
        {
            //Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType));
            HomePage.INSTANCE?.DoChangeView(item);

            IsPresented = false;
        }
        else if (item != null && item.MenuItemType == FlyoutMenuItemType.Title)
        {
            IsFlyoutPrevious = true;
            flyoutPage.collectionView.SelectedItem = e.PreviousSelection.FirstOrDefault() as FlyoutPageItem;
        }
    }
}