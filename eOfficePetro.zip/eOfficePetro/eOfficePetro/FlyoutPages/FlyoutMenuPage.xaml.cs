namespace eOfficePetro.FlyoutPages;

public partial class FlyoutMenuPage : ContentPage
{
	public FlyoutMenuPage()
	{
		InitializeComponent();
    }
}