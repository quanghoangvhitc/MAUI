﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eOfficePetro.FlyoutPages
{
    public class FlyoutPageItem
    {
        public string Title { get; set; }
        public string IconSource { get; set; }
        public Type TargetType { get; set; }
        public FlyoutMenuItem MenuItem { get; set; }
        public FlyoutMenuItemType MenuItemType { get; set; }
        public string NavTitle { get; set; }
    }

    public enum FlyoutMenuItemType
    {
        [Description("Tiêu đề")]
        Title = 0,
        [Description("Menu")]
        Menu = 1,
    }

    public enum FlyoutMenuItem
    {
        #region Trang chủ
        [Description("Trang chủ - Văn bản chờ xử lý")]
        TC_VBChoXuLy = 101,

        [Description("Trang chủ - Thông báo")]
        TC_ThongBao = 102,
        #endregion

        #region Văn bản đến

        [Description("Văn bản đến - Chờ cho ý kiến")]
        VBDen_ChoChoYKien = 201,

        [Description("Văn bản đến - Chờ thực hiện")]
        VBDen_ChoThucHien = 202,

        [Description("Văn bản đến - Đã xử lý")]
        VBDen_DaXuLy = 203,

        [Description("Văn bản đến - Thông báo")]
        VBDen_ThongBao = 204,

        [Description("Văn bản đến - Tất cả")]
        VBDen_TatCa = 205,

        #endregion

        #region Văn bản di

        [Description("Văn bản đi - Chờ phê duyệt")]
        VBDi_ChoPheDuyet = 301,

        [Description("Văn bản đi - Đã phê duyệt")]
        VBDi_DaPheDuyet = 302,

        [Description("Văn bản đi - Đã phát hành")]
        VBDi_DaPhatHanh = 303,

        [Description("Văn bản đi - Thông báo")]
        VBDi_ThongBao = 304,

        [Description("Văn bản đi - Tất cả")]
        VBDi_TatCa = 305,

        #endregion

    }
}
