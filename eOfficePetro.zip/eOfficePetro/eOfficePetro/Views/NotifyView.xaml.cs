namespace eOfficePetro.Views;

public partial class NotifyView : ContentView
{
	public NotifyView()
	{
		InitializeComponent();
	}
}