namespace eOfficePetro.Views;

public partial class VBDenView : ContentView
{
	public VBDenView()
	{
		InitializeComponent();
	}
}