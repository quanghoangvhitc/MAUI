namespace eOfficePetro.Views;

public partial class VBDiView : ContentView
{
	public VBDiView()
	{
		InitializeComponent();
	}
}