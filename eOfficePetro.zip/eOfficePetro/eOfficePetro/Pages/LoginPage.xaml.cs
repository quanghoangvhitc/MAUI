using eOfficePetro.Events;
using eOfficePetro.FlyoutPages;

namespace eOfficePetro.Pages;

public partial class LoginPage : ContentPage
{
    public static event EventHandler<ContentPageDoEvent> DoEvent;
    public static void Do_EventArgs(object sender, ContentPageDoEvent e)
    {
        if (DoEvent != null)
            DoEvent(sender, e);
    }
    public LoginPage()
	{
		InitializeComponent();
	}

    private async void btnLogin_Clicked(object sender, EventArgs e)
    {
        Do_EventArgs(sender, new ContentPageDoEvent(nameof(LoginPage), "btnLogin", e));
        //await App.Current.Dispatcher.DispatchAsync(new Action(() =>
        //{
        //    App.Current.MainPage = new NavigationPage(new AppFlyout());
        //}));

        //btnLogin.IsVisible = false;

        //await MFlyout.FadeTo(1, 1000);
    }
}