﻿using eOfficePetro.Events;
using eOfficePetro.FlyoutPages;
using eOfficePetro.Views;
using System.Runtime.CompilerServices;

namespace eOfficePetro.Pages;

public partial class HomePage : ContentPage
{
    public class ContentList
    {
        public string Key { get; set; }
        public ContentView View { get; set; }
        public bool IsVisible { get; set; }
        public ContentList(string Key, ContentView View)
        {
            this.Key = Key;
            this.View = View;
        }
    }
    public static event EventHandler<ContentPageDoEvent> DoEvent;
    public static void Do_EventArgs(object sender, ContentPageDoEvent e)
    {
        if (DoEvent != null)
            DoEvent(sender, e);
    }

    private static HomePage _INSTANCE = null;
    public static HomePage INSTANCE => _INSTANCE;

    private List<ContentList> pages = new List<ContentList>();

    ContentList currentContentView = null;

    public HomePage()
    {
        InitializeComponent();
        _INSTANCE = this;

    }

    public async Task DoChangeView(FlyoutPageItem flyoutPageItem)
    {
        switch (flyoutPageItem.MenuItem)
        {
            #region Trang chủ
            case FlyoutMenuItem.TC_VBChoXuLy:
                {
                    SetViewVisible(typeof(NotifyView));
                }
                break;
            case FlyoutMenuItem.TC_ThongBao:
                {
                    SetViewVisible(typeof(NotifyView));
                }
                break;
            #endregion

            #region Văn bản đến
            case FlyoutMenuItem.VBDen_ChoChoYKien:
                {
                    SetViewVisible(typeof(VBDenView));
                }
                break;
            case FlyoutMenuItem.VBDen_ChoThucHien:
                {
                    SetViewVisible(typeof(VBDenView));
                }
                break;
            case FlyoutMenuItem.VBDen_DaXuLy:
                {
                    SetViewVisible(typeof(VBDenView));
                }
                break;
            case FlyoutMenuItem.VBDen_ThongBao:
                {
                    SetViewVisible(typeof(VBDenView));
                }
                break;
            case FlyoutMenuItem.VBDen_TatCa:
                {
                    SetViewVisible(typeof(VBDenView));
                }
                break;
            #endregion

            #region Văn bản đi
            case FlyoutMenuItem.VBDi_ChoPheDuyet:
                {
                    SetViewVisible(typeof(VBDiView));
                }
                break;
            case FlyoutMenuItem.VBDi_DaPhatHanh:
                {
                    SetViewVisible(typeof(VBDiView));
                }
                break;
            case FlyoutMenuItem.VBDi_DaPheDuyet:
                {
                    SetViewVisible(typeof(VBDiView));
                }
                break;
            case FlyoutMenuItem.VBDi_ThongBao:
                {
                    SetViewVisible(typeof(VBDiView));
                }
                break;
            case FlyoutMenuItem.VBDi_TatCa:
                {
                    SetViewVisible(typeof(VBDiView));
                }
                break;
                #endregion
        }

        lblNavTitle.Text = flyoutPageItem.NavTitle;
    }

    private void imgAvatar_Clicked(object sender, EventArgs e)
    {
        Do_EventArgs(sender, new ContentPageDoEvent(nameof(HomePage), "imgAvatar", e));
    }

    private void SetViewVisible(Type type)
    {
        string Key = type.Name;

        ContentList item = pages.FirstOrDefault(x => x.Key == "Key");
        if (item == null)
        {
            ContentView v = (ContentView)Activator.CreateInstance(type);
            v.Opacity = 0;
            if (v == null)
                return;

            if (currentContentView != null)
            {
                currentContentView.IsVisible = false;
                int index = pages.IndexOf(currentContentView);
                if (index >= 0)
                {
                    View cView = grdContent.Children[index] as View;
                    if (cView != null)
                    {
                        cView.IsVisible = false;
                        cView.Opacity = 0;
                    };
                }
            }

            item = new ContentList("Key", v);
            grdContent.Children.Add(item.View);
            v.FadeTo(1, 250);
        }
        else
        {
            if (item.Key == currentContentView.Key)
                return;

            if (currentContentView != null)
            {
                currentContentView.IsVisible = false;
                int indexCurrent = pages.IndexOf(currentContentView);
                if (indexCurrent >= 0)
                {
                    View currentCView = grdContent.Children[indexCurrent] as View;
                    if (currentCView != null)
                    {
                        currentCView.IsVisible = false;
                        currentCView.Opacity = 0;
                    };
                }
            }

            int index = pages.IndexOf(item);
            item.IsVisible = true;

            View cView = grdContent.Children[index] as View;
            if (cView != null)
            {
                cView.IsVisible = true;
                cView.FadeTo(1, 250);
            };
        }

        currentContentView = item;
    }

    private void bottomTC_TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
    {
        SetViewVisible(typeof(NotifyView));
    }

    private void bottomVBDen_TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
    {
        SetViewVisible(typeof(VBDenView));
    }

    private void bottomVBDi_TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
    {
        SetViewVisible(typeof(VBDiView));
    }
}