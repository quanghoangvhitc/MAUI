﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eOfficePetro.Common
{
    public class CmmVariable
    {
        public static string DOMAIN = "";
        public static string SUBSITE = "";
    }
}
